<?php
require_once __DIR__ . '/../../../models/setup/banksetup/delete.php';
// The model file already handles the delete operation logic
?>