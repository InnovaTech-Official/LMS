<?php
require_once __DIR__ . '/../../../models/setup/banksetup/edit.php';
// The model file already handles the form submission logic
?>