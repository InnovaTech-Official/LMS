<?php
require_once __DIR__ . '/../../../models/setup/banksetup/post.php';
// The model file already handles the form submission logic
?>